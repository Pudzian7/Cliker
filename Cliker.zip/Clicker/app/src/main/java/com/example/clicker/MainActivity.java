package com.example.clicker;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button incrementButton;
    private Button resetButton;
    private Switch switchButton;
    private TextView counterTextView;

    private int counter = 0;
    private boolean isPositiveMode = true;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        incrementButton = findViewById(R.id.incrementButton);
        resetButton = findViewById(R.id.resetButton);
        switchButton = findViewById(R.id.switchButton);
        counterTextView = findViewById(R.id.counterTextView);

        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPositiveMode) {
                    counter++;
                } else {
                    counter--;
                }
                updateCounterTextView();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter = 0;
                updateCounterTextView();
            }
        });

        switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isPositiveMode = !isChecked;
            }
        });
    }

    private void updateCounterTextView() {
        counterTextView.setText("Licznik: " + counter);
    }
}
